#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include "split.hpp"
#include "spp/CoordTrans.h"
#include "spp/CMatrix.h"
#include <math.h>
#include <iomanip>
using namespace std;
using namespace P_Struct;
typedef struct Record{
    long long timestamp;
    double x,y,z;
    double vx,vy,vz;
} Rec;

    

int main()
{
    cout<<"Hello World!"<<endl;
    vector<Rec> Recs;
    Geodetic geod={114.366956,30.54104};
    Cartesian cart=CoordTrans::Geod2Cart(geod);

    CMatrix R = CMatrix(3, 3);
	
    CMatrix t=CMatrix(3,1);
	double B = geod.B*pi / 180;
	double L = geod.L*pi / 180;

	R.Set_number(0, 0, -sin(B)*cos(L));
	R.Set_number(0, 1, -sin(B)*sin(L));
	R.Set_number(0, 2, cos(B));
	R.Set_number(1, 0, -sin(L));
	R.Set_number(1, 1, cos(L));
	R.Set_number(1, 2, 0);
	R.Set_number(2, 0, cos(B)*cos(L));
	R.Set_number(2, 1, cos(B)*sin(L));
	R.Set_number(2, 2, sin(B));
	R = CMatrix::Inverse(R);

    t.Set_number(0,0,cart.X);
    t.Set_number(1,0,cart.Y);
    t.Set_number(2,0,cart.Z);








    ifstream ifs("MH03.txt");
    ofstream ofs("output.txt");
	ofs << "#timestamp,x,y,z,vx,vy,vz" << endl;
    while(ifs.good())
    {
        string line;
        getline(ifs,line);
        if(line[0]=='#') continue;
        vector<string> buffer=split(line,",");
        if(buffer.size()<11) continue;
        double ts=stoll(buffer[0]);
        double x=stod(buffer[1]);
        double y=stod(buffer[2]);
        double z=stod(buffer[3]);
        double vx=stod(buffer[8]);
        double vy=stod(buffer[9]);
        double vz=stod(buffer[10]);
        CMatrix pos=CMatrix(3,1);
        CMatrix vel=CMatrix(3,1);
        pos.Set_number(0,0,x);
        pos.Set_number(1,0,y);
        pos.Set_number(2,0,z);
        vel.Set_number(0,0,vx);
        vel.Set_number(1,0,vy);
        vel.Set_number(2,0,vz);
        pos=R*pos+t;
        vel=R*vel;

        ofs<<setprecision(20)<<ts<<" "
            <<setprecision(15)<<pos.Num(0,0)<<" "
            <<setprecision(15)<<pos.Num(1,0)<<" "
            <<setprecision(15)<<pos.Num(2,0)<<" "
            <<setprecision(15)<<vel.Num(0,0)<<" "
            <<setprecision(15)<<vel.Num(1,0)<<" "
            <<setprecision(15)<<vel.Num(2,0)<<endl;
    
        

    }
    ifs.close();
    ofs.close();
    

    cin.get();
    return 0;

}